﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using product.BL;
namespace product
{
    class Program
    {
        static void Main(string[] args)
        {
            p_class[] pro = new p_class[3];
            int count = 0;
            string option;
            while(true )
            {
                option = menu();
                if(option == "1")
                {
                    Console.Clear();
                    pro[count] = addp();
                    count++;
                    Console.ReadKey();
                    Console.Clear();
                }
                else if (option == "2")
                {
                    Console.Clear();
                    show_product(count, pro);
                    Console.ReadKey();
                    Console.Clear();
                }

                else if (option == "3")
                {
                    Console.Clear();
                    show_wirth(pro , count);
                    Console.ReadKey();
                    Console.Clear();
                }
                
            }
        }

        static p_class addp()
        {
            p_class a = new p_class();
            Console.WriteLine("Enter The Id ");
            a.id = Console.ReadLine();
            Console.WriteLine("Enter The Name");
            a.name = Console.ReadLine();
            Console.Write("Enter The price");
            a.price = int.Parse(Console.ReadLine());
            Console.Write("Enter The Category");
            a.catag = Console.ReadLine();
            Console.Write("Enter The Brand name");
            a.brad= char.Parse(Console.ReadLine());
            Console.Write("Enter The Country name");
            a.country = Console.ReadLine();
            return a;
        }
        static void show_product(int count   , p_class[] name )  
        {
            Console.WriteLine("name" + "\t\t" + "id" + "\t\t"+ "price" + "\t\t" + "catagory"  + "\t\t" + "brand"  +  "\t\t" + "country");
            for(int i  = 0; i <count; i ++ )
            {
                Console.WriteLine(name[i].name + name[i].id + name[i].price + name[i].catag + name[i].brad + name[i].country);
            }
            Console.ReadKey();
        }


        static void show_wirth( p_class [] s  , int count  )
        {
            int sum = 0;
            for(int i  =  0; i<count; i++)
            {
                sum =  sum +  s[i].price;
            }
            Console.WriteLine("Total Worth is = " + "\t\t" + sum);
        }

        static string  menu ()
        {
            string option;
            Console.WriteLine("1) Add product ");
            Console.WriteLine("2) Show product ");
            Console.WriteLine("3) Show total  price ");
            Console.Write("Enter your option ");
            option = Console.ReadLine();
            Console.Clear();
            return option;
        }



    }
}
