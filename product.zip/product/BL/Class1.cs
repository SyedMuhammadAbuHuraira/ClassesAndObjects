﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace product.BL
{
    class p_class 
    {
        public string id;
        public string name;
        public int price;
        public string catag;
        public char brad;
        public string country;
    }
}
