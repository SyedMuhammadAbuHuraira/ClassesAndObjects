﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Oop_Task_1.BL;
namespace Oop_Task_1
{
    class Program
    {
        static void Main(string[] args)
        {
            string p;
            int option;
            int count = 0;
            student[] s1 = new student[5];
            while (true)
            {
                p = Menu();
                if (p == "1")
                {
                    Console.Clear();
                   
                    s1[count] = addUser();
                    count++;
                    Console.ReadKey();
                    Console.Clear();
                }
                else if (p == "2")
                {
                    Console.Clear();
                    showUser(s1, count);
                    Console.ReadKey();
                    Console.Clear();
                }
                else if (p == "3")
                {
                    Console.Clear();
                    Top_user(count, s1);
                    Console.ReadKey();
                    Console.Clear();
                }
                else if (p == "4")
                {
                    break;
                    break;
                }
            }
        }
        static student addUser()
        {
            student s = new student(); 
            Console.Write("Enter The name !!!");
            s.sname = Console.ReadLine();
            Console.Write("Enter The matric marks !!!");
            s.matricMarks = int.Parse(Console.ReadLine());
            Console.Write("Enter The fsc marks !!!");
            s.fscMarks = int.Parse(Console.ReadLine());
            Console.Write("Enter The ecat marks !!!");
            s.ecatMarks = int.Parse(Console.ReadLine());
            s.aggregate =  calculateMerit(s);
            return s;
        }
        static float calculateMerit(student  name)
        {
            float score;
            score = ((0.25F * (name.matricMarks / 1050)) + (0.45F * (name.fscMarks / 550)) + (0.3F *

            (name.ecatMarks / 400))) * 100;

            return score;
        }
        static void showUser(student[] name, int count)
        {
            Console.Write("Name");
            Console.Write("\t\t");
            Console.Write("Matric Marks");
            Console.Write("\t\t");
            Console.Write("Fsc_Marks");
            Console.Write("\t\t");
            Console.Write("Ecat_Marks");
            Console.Write("\t");
            Console.Write("Aggregate");
            Console.WriteLine();
            Console.Write("----");
            Console.Write("\t\t");
            Console.Write("----");
            Console.Write("\t\t");
            Console.Write("----");
            Console.Write("\t\t");
            Console.Write("-----");
            Console.Write("\t\t");
            Console.Write("-----");
            Console.Write("\t\t");
            Console.WriteLine();
            for (int i = 0; i < count; i++)
            {

                // Console.WriteLine(name[i].sname + "\t\t" + name[i].matricMarks + "\t\t" + name[i].fscMarks + "\t\t" + name[i].ecatMarks + "\t\t" + name[i].aggregate);
                Console.Write(name[i].sname);
                Console.Write("\t\t");
                Console.Write(name[i].matricMarks);
                Console.Write("\t\t");
                Console.Write(name[i].fscMarks);
                Console.Write("\t\t");
                Console.Write(name[i].ecatMarks);
                Console.Write("\t\t");
                Console.Write(name[i].aggregate);
                Console.Write("\t\t");
                Console.WriteLine();
            }
        }
        
        static void Top_user(int customer_count, student [] name  ) 
        {
            for (int i = 0; i < customer_count; i++)
            {
                for (int j = 0; j < customer_count - i - 1; j++)
                {
                    if (name[j].aggregate > name[j + 1].aggregate)
                    {
                        float temp = name[j].aggregate;
                        name[j].aggregate = name[j + 1].aggregate;
                        name[j + 1].aggregate = temp;

                        float temp_2 = name[j].ecatMarks;
                        name[j].ecatMarks = name[j + 1].ecatMarks;
                        name[j + 1].ecatMarks = temp;


                        string temp1 = name[j].sname;
                        name[j].sname = name[j + 1].sname;
                        name[j + 1].sname = temp1;


                        temp_2 = name[j].fscMarks;
                        name[j].fscMarks = name[j + 1].fscMarks;
                        name[j + 1].fscMarks = temp_2;

                        temp_2 = name[j].matricMarks;
                        name[j].matricMarks = name[j + 1].matricMarks;
                        name[j + 1].matricMarks = temp_2;


                    }
                }
            }
            Console.Write("Name");
            Console.Write("\t\t");
            Console.Write("Matric Marks");
            Console.Write("\t\t");
            Console.Write("Fsc_Marks");
            Console.Write("\t\t");
            Console.Write("Ecat_Marks");
            Console.Write("\t");
            Console.Write("Aggregate");
            Console.WriteLine();
            Console.Write("----");
            Console.Write("\t\t");
            Console.Write("----");
            Console.Write("\t\t");
            Console.Write("----");
            Console.Write("\t\t");
            Console.Write("-----");
            Console.Write("\t\t");
            Console.Write("-----");
            Console.Write("\t\t");
            Console.WriteLine();
            for (int p = 0; p < 3; p++)
                {
                Console.Write(name[p].sname);
                Console.Write("\t\t");
                Console.Write(name[p].matricMarks);
                Console.Write("\t\t");
                Console.Write(name[p].fscMarks);
                Console.Write("\t\t");
                Console.Write(name[p].ecatMarks);
                Console.Write("\t\t");
                Console.Write(name[p].aggregate);
                Console.Write("\t\t");
                Console.WriteLine();

            }
            }



        static string Menu()
        {
            string x;
            Console.WriteLine("1 - Add User!!!");
            Console.WriteLine("2 - Show User!!!");
            Console.WriteLine("3 - Top User!!!");
            Console.WriteLine("4 - Exit!!!");
            Console.WriteLine("Enter Your Option!!!");
            x = Console.ReadLine();
            return x;
        } 
        }
    }


